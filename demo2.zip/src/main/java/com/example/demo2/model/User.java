package com.example.demo2.model;

public class User
{
    private Integer id;

    private String name;

    private Integer age;

}
