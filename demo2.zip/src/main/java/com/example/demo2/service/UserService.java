package com.example.demo2.service;

import com.example.demo2.model.User;

import java.util.List;

public interface UserService
{
    List<User> select();
}
